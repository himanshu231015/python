from django.urls import path
from . import views
urlpatterns ={
    path("images/",views.upload_image,name='upload_image')
}